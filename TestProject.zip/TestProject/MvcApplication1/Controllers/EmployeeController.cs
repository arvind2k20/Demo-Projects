﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Save(Employee emp)
        {
           
            return Json(new{Status="Success"}, JsonRequestBehavior.AllowGet);

        }


        public JsonResult GetEmplyee()
        {

            return Json(
                new Employee()
                {
                    FirstName = "Akhilesh", 
                    LastName = "Singh", 
                    Email = "Akhilesh.Singh@virtualemployee"
                }, 
                JsonRequestBehavior.AllowGet);

        }


    }
}
