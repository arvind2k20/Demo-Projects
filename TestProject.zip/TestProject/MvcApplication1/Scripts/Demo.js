﻿var mainApp = angular.module("mainApp", []);

mainApp.controller('StudentController', function ($scope, $http,EmpService) {

    $scope.Employee = {};

    $scope.Getdata = function () {
        EmpService.GetEmploye()
       .then(function successCallback(response) {
            $scope.Employee = response.data;
        });
    }

    $scope.Save = function () {
        EmpService.Save($scope.Employee)
            .then(function successCallback(response) {
                alert(response.data.Status);
            });
    }

    //$scope.reset();
    //$scope.reset = function () {
    //    $scope.Employee.FirstName = "Mahesh";
    //    $scope.Employee.LastName = "Parashar";
    //    $scope.Employee.Email = "MaheshParashar@tutorialspoint.com";
    //}
});

mainApp.service('EmpService', function ($http) {
    this.GetEmploye = function () {
        return $http({
            method: "Get",
            url: "/Employee/GetEmplyee",
            dataType: "json"
        });
    }


    this.Save = function (Employee) {
        return  $http({
            method: "post",
            url: "/Employee/Save",
            data: { "emp": Employee },
            dataType: "json"
        })

    }
});

