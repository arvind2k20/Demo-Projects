﻿// Type: Custom Directives
// Purpose: contains all general directives

(function () {
    'use strict';
    var app = angular.module('enukeService');
    //created by : Mahesh Verma
    //check and ensure that input character is alphabet
    //where to used : dataDetail.html
    app.directive('onlyAlphabets', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function inputText(text) {
                    var transformedInput = text.replace(/[^A-Za-z ]/g, '');
                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                ngModelCtrl.$parsers.push(inputText);
            }
        };
    });
 


})();