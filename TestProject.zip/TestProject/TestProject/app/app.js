﻿var app = angular.module('enukeService', [
    'ngMaterial',
    'ngRoute',
    'ngAnimate',
    'ngAria',
    'angularUtils.directives.dirPagination',
    'ui.bootstrap'
]);

app.filter('abc', function () {
    return function (Name) {
        if (Name == 'Basant') {
            return 'Hello';
        } else {
            return 'hi';
        }
    }
});
