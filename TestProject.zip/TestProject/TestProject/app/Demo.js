﻿var mainApp = angular.module("mainApp", []);

mainApp.controller('StudentController', function ($scope) {
    $scope.Employee = {};


    $scope.reset = function() {
        $scope.Employee.firstName = "Mahesh";
        $scope.lastName = "Parashar";
        $scope.email = "MaheshParashar@tutorialspoint.com";
    }

});












    mainApp.directive('student', function () {
        //define the directive object
        var directive = {};

        //restrict = E, signifies that directive is Element directive
        directive.restrict = 'E';

        //template replaces the complete element with its text. 
        directive.template = "<input ng-model='student.name'>Student: <b>{{student.name}}</b> , Roll No: <b>{{student.rollno}}</b>";

        //scope is used to distinguish each student element based on criteria.
        directive.scope = {
            student: "=name"
        }

        //compile is called during application initialization. AngularJS calls it once when html page is loaded.

        directive.compile = function (element, attributes) {
            element.css("border", "1px solid #cccccc");

            //linkFunction is linked with each element with scope to get the element specific data.
            var linkFunction = function ($scope, element, attributes) {
                if ($scope.student.name == 'a') {
                    debugger;
                    alert();
                    element.css("background-color", "000000");
                }
                    // element.html("<input ng-model=student.name>Student: <b>" + $scope.student.name + "</b> , Roll No: <b>" + $scope.student.rollno + "</b><br/>");
                else {
                    element.css("background-color", "#ff00ff");
                }
            }
            return linkFunction;
        }
        return directive;
    });
