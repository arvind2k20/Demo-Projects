﻿(function () {
    'use strict';
    app.config(['$routeProvider', function ($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: '/ui/dashboard.html',
                controller: 'DashboardCtrl'
            })
            .when('/:id', {
                templateUrl:'/ui/dataDetail.html',
                controller: 'DataDetailsCtrl'
            })
             .otherwise({
                 redirectTo: '/ui/index.html#/',
             });
      }]);
})();




