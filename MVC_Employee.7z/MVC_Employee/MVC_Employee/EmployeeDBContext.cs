﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MVC_Employee
{
    public class EmployeeDBContext :DbContext
    {
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Employee>()
                .HasKey(pk => pk.empID)
                .ToTable("Employees");

            modelBuilder.Entity<EmployeeDetail>()
                .HasKey(pk => pk.empID)
                .ToTable("Employees");

            modelBuilder.Entity<Employee>()
                .HasRequired(p => p.EmployeeDetail)
                .WithRequiredPrincipal(c => c.Employee);            

            
        }
    }
}