﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace MVC_Employee.Models
{
    public class EmployeesModel
    {
        public int empID { get; set; }

        [DisplayName("First Name")]
        [Required (ErrorMessage="* Please enter First Name.",AllowEmptyStrings=false) ]
        public string empFName { get; set; }

         [DisplayName("Last Name")]
        public string empLName { get; set; }

         [DisplayName("Gender")]
         [Required(ErrorMessage = "* Please enter Gender", AllowEmptyStrings = false)]
        public string empGender { get; set; }

         [DisplayName("Phone")]
         [Required(ErrorMessage = "* Please enter Phone", AllowEmptyStrings = false)]
        public string empPhone { get; set; }

         [DisplayName("Address")]
        public string empAddress { get; set; }

         [DisplayName("Email ID")]
         [Required(ErrorMessage = "* Please enter Email ID", AllowEmptyStrings = false)]
        public string empEmailID { get; set; }


        private readonly EmployeeDBContext OE = new EmployeeDBContext();

        public IEnumerable<Employee> GetEmployee()
        {
            return OE.Employees.ToList();
        }

        public IEnumerable<Employee> DisplayEmployee(string emplpoyeename)
        {
            List<Employee> ef=new List<Employee>();
            
            if (OE.Employees.Where(x => x.empFName.Contains(emplpoyeename))!=null)
            { 
                ef = OE.Employees.Where(x => x.empFName.Contains(emplpoyeename)).ToList();
                
            }
            else if(OE.Employees.Where(x => x.empLName.Contains(emplpoyeename))!=null)
            {
                ef = OE.Employees.Where(x => x.empLName.Contains(emplpoyeename)).ToList();
            }

            return ef;
            
        }

        public Employee GetEmployeeDetail(int EmployeeID)
        {
            var result = from emp in OE.Employees.Include("EmployeeDetail")
                         where emp.empID == EmployeeID
                         select emp;

            var enEmployee = result.FirstOrDefault<Employee>();
            return enEmployee;
        }

        public bool AddEmployee(EmployeesModel emp)
        {
            try
            {
                Employee empObj = new Employee();
                empObj.empID = emp.empID;
                empObj.empFName = emp.empFName;
                empObj.empLName = emp.empLName;
                empObj.empGender = emp.empGender;

                EmployeeDetail empdetObj = new EmployeeDetail();
                empdetObj.empID = emp.empID;
                empdetObj.empPhone = emp.empPhone;
                empdetObj.empAddress = emp.empAddress;
                empdetObj.empEmailID = emp.empEmailID;

                empObj.EmployeeDetail = empdetObj;

                OE.Employees.Add(empObj);
                OE.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool EditEmployee(Employee emp)
        {
            try
            {
               var result = from tempemp in OE.Employees.Include("EmployeeDetail")
                             where tempemp.empID == emp.empID
                             select tempemp;

                Employee enEmployee = result.FirstOrDefault<Employee>();
                
                enEmployee.empID = emp.empID;
                enEmployee.empFName = emp.empFName;
                enEmployee.empLName = emp.empLName;
                enEmployee.empGender = emp.empGender;

                EmployeeDetail ed = new EmployeeDetail();
                ed.empID = emp.EmployeeDetail.empID;
                ed.empAddress = emp.EmployeeDetail.empAddress;
                ed.empPhone = emp.EmployeeDetail.empPhone;
                ed.empEmailID = emp.EmployeeDetail.empEmailID;
                enEmployee.EmployeeDetail = ed;
               
                OE.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteEmployee(int EmployeeID)
        {
            try
            {
               Employee data= GetEmployeeDetail(EmployeeID);
                    
               OE.Employees.Remove(data);
                OE.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public void Dispose()
        {
            OE.Dispose();
        }
    }
}