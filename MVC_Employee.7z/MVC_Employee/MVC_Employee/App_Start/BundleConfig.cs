﻿using System.Web;
using System.Web.Optimization;

namespace MVC_Employee
{
    public class BundleConfig
    {
 
        public static void RegisterBundles(BundleCollection bundles)
        {
            //js
            bundles.Add(new ScriptBundle("~/jquery-1.7.2.min.js").Include(
                        "~/Scripts/jquery-1.7.2.min.js"));
            bundles.Add(new ScriptBundle("~/jquery.validate.min.js").Include(
                        "~/Scripts/jquery.validate.min.js"));
            bundles.Add(new ScriptBundle("~/jquery.validate.unobtrusive.min.js").Include(
                        "~/Scripts/jquery.validate.unobtrusive.min.js"));
            bundles.Add(new ScriptBundle("~/jquery-ui-1.8.20.min.js").Include(
                        "~/Scripts/jquery-ui-1.8.20.min.js"));


            //css
            bundles.Add(new StyleBundle("~/css").Include("~/Content/site.css"));
            bundles.Add(new StyleBundle("~/css/jquery-ui.min.css").Include("~/Content/themes/base/minified/jquery-ui.min.css"));

            
        }
    }
}