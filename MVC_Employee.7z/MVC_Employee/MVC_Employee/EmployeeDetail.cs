﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_Employee
{
    public class EmployeeDetail
    {
        public int empID { get; set; }
        public string empPhone { get; set; }
        public string empAddress { get; set; }
        public string empEmailID { get; set; }

        public Employee Employee { get; set; }
    }
}