﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_Employee.Models;

namespace MVC_Employee.Controllers
{
    public class ManageEmployeeController : Controller
    {
        EmployeesModel EM=new EmployeesModel();

        public ActionResult Index(IEnumerable<Employee> emp)
        {
            if (emp!=null)
            {
                return View(emp);
            }
            else
            {
                return View(EM.GetEmployee());
            }
            
            
        }

        public ActionResult SearchEmployee(string txtsearch)
        {
            var empSearch = EM.DisplayEmployee(txtsearch);
            return View("Index",empSearch);
        }

        public ActionResult AddEmployee()
        {
            if (Request.IsAjaxRequest())
            {
                ViewBag.IsUpdate = false;
                return View("_AddEmployee");
            }
            else

                return View();
        }

        [HttpPost]
        public ActionResult AddEmployee(EmployeesModel emp, string Command)
        {
            if (!ModelState.IsValid)
            {
                return PartialView("_AddEmployee", emp);
            }
            else
            {
                bool IsSuccess = EM.AddEmployee(emp);
                
                if (IsSuccess)
                {
                    TempData["OperStatus"] = "Employee added succeessfully";
                    ModelState.Clear();
                    return RedirectToAction("Index");
                }
            }

            return PartialView("_AddEmployee");
        }

        public ActionResult DisplayEmployee(int Id)
        {
            var data = EM.GetEmployeeDetail(Id);
            if (Request.IsAjaxRequest())
            {
                EmployeesModel empObj = new EmployeesModel();

                empObj.empID = data.empID;
                empObj.empFName = data.empFName;
                empObj.empLName = data.empLName;
                empObj.empGender = data.empGender;
                empObj.empAddress = data.EmployeeDetail.empAddress;
                empObj.empPhone = data.EmployeeDetail.empPhone;
                empObj.empEmailID = data.EmployeeDetail.empEmailID;

                return View("_DisplayEmployee", empObj);
            }
            else

                return View(data);

        }

        public ActionResult EditEmployee(int id)
        {
            var data = EM.GetEmployeeDetail(id);

            if (Request.IsAjaxRequest())
            {
                EmployeesModel empMod = new EmployeesModel();

                empMod.empID = data.empID;
                empMod.empFName = data.empFName;
                empMod.empLName = data.empLName;
                empMod.empGender = data.empGender;
                empMod.empAddress = data.EmployeeDetail.empAddress;
                empMod.empPhone = data.EmployeeDetail.empPhone;
                empMod.empEmailID = data.EmployeeDetail.empEmailID;

                ViewBag.IsUpdate = true;
                return View("_EditEmployee", empMod);
            }
            else
                return View(data);
        }

         [HttpPost]
        public ActionResult EditEmployee(EmployeesModel empMod, string Command)
        {
            if (!ModelState.IsValid)
            {
                return PartialView("_EditEmployee", empMod);
            }
            else
            {
                Employee empObj = new Employee();
                empObj.empID = empMod.empID;
                empObj.empFName = empMod.empFName;
                empObj.empLName = empMod.empLName;
                empObj.empGender = empMod.empGender;

                EmployeeDetail empdet = new EmployeeDetail();
                empdet.empID = empMod.empID;
                empdet.empAddress = empMod.empAddress;
                empdet.empPhone = empMod.empPhone;
                empdet.empEmailID = empMod.empEmailID;

                empObj.EmployeeDetail = empdet;
                
                bool IsSuccess = EM.EditEmployee(empObj);
                if (IsSuccess)
                {
                    TempData["OperStatus"] = "Employee updated succeessfully";
                    ModelState.Clear();
                    return RedirectToAction("Index");
                }
            }

            return PartialView("_EditEmployee");
        }

         public ActionResult DeleteEmployee(int id)
         {
             bool check = EM.DeleteEmployee(id);
             //var data = EM.GetEmployee();
             return RedirectToAction("Index");
         }

    }
}
