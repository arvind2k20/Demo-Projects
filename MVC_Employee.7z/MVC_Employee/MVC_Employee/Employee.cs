﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_Employee
{
    public class Employee
    {
        public int empID { get; set; }
        public string empFName { get; set; }
        public string empLName { get; set; }
        public string empGender { get; set; }

        public EmployeeDetail EmployeeDetail { get; set; }
        
    }
}