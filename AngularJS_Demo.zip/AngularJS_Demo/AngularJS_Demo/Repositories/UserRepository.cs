﻿using AngularJS_Demo.Interface;
using AngularJS_Demo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AngularJS_Demo.Repositories
{

    public class UserRepository : IUserRepository
    {
        FileAccessSystemEntities UserDB = new FileAccessSystemEntities();
        
        public IEnumerable<User> GetAll()
        {
            // TO DO : Code to get the list of all the records in database
            return UserDB.Users;
        }

        public User Get(int id)
        {
            // TO DO : Code to find a record in database
            return UserDB.Users.Find(id);
        }

        public User Add(User item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            // TO DO : Code to save record into database
            UserDB.Users.Add(item);
            UserDB.SaveChanges();
            return item;
        }

        public bool Update(User item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            // TO DO : Code to update record into database
            var users = UserDB.Users.Single(a => a.Id == item.Id);
            users.Name = item.Name;
            users.Email = item.Email;
            users.Address = item.Address;
            users.LoginName = item.LoginName;
            users.Password = item.Password;
            UserDB.SaveChanges();
            return true;
        }

        public bool Delete(int id)
        {
            // TO DO : Code to remove the records from database
            User user = UserDB.Users.Find(id);
            UserDB.Users.Remove(user);
            UserDB.SaveChanges();
            return true;
        }
    }
}
