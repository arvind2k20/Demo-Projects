﻿// Defining angularjs module
var app = angular.module('demoModule', []);

// Defining angularjs Controller and injecting UsersService
app.controller('demoCtrl', function ($scope, $http, UsersService) {
    $scope.usersData = null;
    // Fetching records from the factory created at the bottom of the script file
    UsersService.GetAllRecords().then(function (d) {
        $scope.usersData = d.data; // Success
    }, function () {
        alert('Error Occured !!!'); // Failed
    });  

    $scope.Users = {
        Id: '',
        Name: '',
        Email: '',
        Address: '',
        LoginName: '',
        Password:''
    };

    // Reset product details
    $scope.clear = function () {
        $scope.Users.Id = '';
        $scope.Users.Name = '';
        $scope.Users.Email = '';
        $scope.Users.Address = '';
        $scope.Users.LoginName = '';
        $scope.Users.Password = '';
    }

    //Add New Item
    $scope.save = function () {
        debugger;
        if ($scope.Users.Name != "" &&
       $scope.Users.LoginName != "" && $scope.Users.Password != "") {            
            // or you can call Http request using $http
            $http({
                method: 'POST',
                url: 'api/User/PostUser/',
                data: $scope.Users
            }).then(function successCallback(response) {
                // this callback will be called asynchronously
                // when the response is available
                $scope.usersData.push(response.data);
                $scope.clear();
                alert("User Added Successfully !!!");
            }, function errorCallback(response) {
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                alert("Error : " + response.data.ExceptionMessage);
            });
        }
        else {
            alert('Please Enter All the Values !!');
        }
    };

    // Edit product details
    $scope.edit = function (data) {
        $scope.Users = { Id: data.Id, Name: data.Name, Email: data.Email, Address: data.Address, LoginName: data.LoginName, Password: data.Password };
    }

    // Cancel product details
    $scope.cancel = function () {
        $scope.clear();
    }

    // Update product details
    $scope.update = function () {
        debugger;
        if ($scope.Users.Name != "" &&
       $scope.Users.LoginName != "" && $scope.Users.Password != "") {
            $http({
                method: 'PUT',
                url: 'api/User/PutUser/' + $scope.Users.Id,
                data: $scope.Users
            }).then(function successCallback(response) {
                $scope.usersData = response.data;
                $scope.clear();
                alert("User Updated Successfully !!!");
            }, function errorCallback(response) {
                alert("Error : " + response.data.ExceptionMessage);
            });
        }
        else {
            alert('Please Enter All the Values !!');
        }
    };

    // Delete product details
    $scope.delete = function (index) {
        $http({
            method: 'DELETE',
            url: 'api/User/DeleteUser/' + $scope.usersData[index].Id,
        }).then(function successCallback(response) {
            $scope.usersData.splice(index, 1);
            alert("User Deleted Successfully !!!");
        }, function errorCallback(response) {
            alert("Error : " + response.data.ExceptionMessage);
        });
    };

});
app.factory('UsersService', function ($http) {
    var fac = {};  
    fac.GetAllRecords = function () {
        return $http.get('api/User/GetAllUsers');
    }
    return fac;
});