﻿using AngularJS_Demo.Interface;
using AngularJS_Demo.Repositories;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using AngularJS_Demo.Models;
using System.Web.Http;

namespace AngularJS_Demo.Controllers
{
    public class UserController : ApiController
    {
        static readonly IUserRepository repository = new UserRepository();

        public IEnumerable GetAllUsers()
        {
            return repository.GetAll();
        }

        public User PostUser(User item)
        {
            return repository.Add(item);
        }

        public IEnumerable PutUser(int id, User user)
        {
            user.Id = id;
            if (repository.Update(user))
            {
                return repository.GetAll();
            }
            else
            {
                return null;
            }
        }

        public bool DeleteUser(int id)
        {
            if (repository.Delete(id))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
